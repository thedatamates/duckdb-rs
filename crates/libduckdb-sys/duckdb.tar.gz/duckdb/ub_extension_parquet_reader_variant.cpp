#include "extension/parquet/reader/variant/variant_binary_decoder.cpp"

#include "extension/parquet/reader/variant/variant_shredded_conversion.cpp"

