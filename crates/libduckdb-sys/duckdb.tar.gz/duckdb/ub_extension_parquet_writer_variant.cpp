#include "extension/parquet/writer/variant/convert_variant.cpp"

#include "extension/parquet/writer/variant/analyze_variant.cpp"

