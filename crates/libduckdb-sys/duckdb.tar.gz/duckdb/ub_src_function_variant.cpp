#include "src/function/variant/variant_shredding.cpp"

