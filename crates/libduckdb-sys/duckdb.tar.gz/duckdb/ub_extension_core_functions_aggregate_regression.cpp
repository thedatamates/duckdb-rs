#include "extension/core_functions/aggregate/regression/regr_sxy.cpp"

#include "extension/core_functions/aggregate/regression/regr_intercept.cpp"

#include "extension/core_functions/aggregate/regression/regr_count.cpp"

#include "extension/core_functions/aggregate/regression/regr_r2.cpp"

#include "extension/core_functions/aggregate/regression/regr_avg.cpp"

#include "extension/core_functions/aggregate/regression/regr_slope.cpp"

#include "extension/core_functions/aggregate/regression/regr_sxx_syy.cpp"

