#include "extension/core_functions/scalar/struct/struct_insert.cpp"

#include "extension/core_functions/scalar/struct/struct_update.cpp"

#include "extension/core_functions/scalar/struct/struct_keys.cpp"

