#include "src/function/scalar/geometry/geometry_functions.cpp"

