#include "src/common/types/row/partitioned_tuple_data.cpp"

#include "src/common/types/row/row_data_collection.cpp"

#include "src/common/types/row/row_data_collection_scanner.cpp"

#include "src/common/types/row/row_layout.cpp"

#include "src/common/types/row/tuple_data_allocator.cpp"

#include "src/common/types/row/tuple_data_collection.cpp"

#include "src/common/types/row/tuple_data_iterator.cpp"

#include "src/common/types/row/tuple_data_layout.cpp"

#include "src/common/types/row/tuple_data_scatter_gather.cpp"

#include "src/common/types/row/tuple_data_segment.cpp"

