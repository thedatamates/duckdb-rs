#include "src/function/scalar/variant/variant_utils.cpp"

#include "src/function/scalar/variant/variant_extract.cpp"

#include "src/function/scalar/variant/variant_typeof.cpp"

#include "src/function/scalar/variant/variant_normalize.cpp"

