#include "src/storage/table/variant/variant_shredding.cpp"

#include "src/storage/table/variant/variant_unshredding.cpp"

