#include "src/storage/compression/chimp/bit_reader.cpp"

#include "src/storage/compression/chimp/chimp_constants.cpp"

#include "src/storage/compression/chimp/flag_buffer.cpp"

#include "src/storage/compression/chimp/leading_zero_buffer.cpp"

#include "src/storage/compression/chimp/chimp.cpp"

